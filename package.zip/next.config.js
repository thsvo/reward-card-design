const nextConfig = {
    reactStrictMode: true,
    distDir: 'dist'
};

module.exports = nextConfig;